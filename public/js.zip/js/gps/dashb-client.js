var client_lat = $('#lat').val();
var client_lng = $('#lng').val();
var latMap = parseFloat(client_lat);
var lngMap = parseFloat(client_lng);
var haightAshbury = {
  lat: latMap,
  lng: lngMap
};
var refesh_flag=0;
var markers = [];
var map;
var map_flag;
var flag=0;
var track_flag = 0;
var map_popup = 0;
var radius;
var cityCircle;
var circleStatus=0;
var myGoogleRadar;
var radarStatus=0;

var selected_vehicle_mode = null;

function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 10,
    center: haightAshbury,
    fullscreenControl: false,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  var input1 = document.getElementById('search_place');
  autocomplete1 = new google.maps.places.Autocomplete(input1);
  var searchBox1 = new google.maps.places.SearchBox(autocomplete1);
  map_flag = 0;
  getVehicleSequence();

  map.addListener('zoom_changed', function() {
    localStorage.setItem('googleMapZoomLevel', map.getZoom());


  });
}

// check each 10 sec
window.setInterval(function() {
  if (track_flag == 0 && refesh_flag==0) {
    dashcount();
    getVehicleSequence();
  }
}, 10000);
// check each 10 sec

function getVehicleSequence() {
  var url = 'dash-vehicle-track';
  var data = {};
  backgroundPostData(url, data, 'vehicleTrack', {
    alert: false
  });
  deleteMarkers();
}

function dashcount() {
  var url = 'dash-count';
  var data = {};
  backgroundPostData(url, data, 'modecount', {alert: false});
  // deleteMarkers();
}

function modecount(res) {
  $('#moving').text(res.moving);
  $('#idle').text(res.idle);
  $('#stop').text(res.stop);
  $('#offline').text(res.offline);
}

function vehicleTrack(res) {

  if(res.status!="failed"){
    var JSONObject = res.user_data;
    //console.log(JSONObject);
    var marker, i;
    for (i = 0; i < JSONObject.length; i++) {
    var lat = JSONObject[i].lat;
    var lng = JSONObject[i].lon;
    // alert(flag);
    if (map_flag == 0) {
      map.panTo(new google.maps.LatLng(lat, lng));
      // check if zoom level is already set
      var zoom_level = 13;
      if( localStorage.getItem('googleMapZoomLevel') != null )
      {
        zoom_level = localStorage.getItem('googleMapZoomLevel') * 1;
      }
      map.setZoom(zoom_level);
      map.setOptions({
      minZoom: 5,
      maxZoom: 17
      });
      // map_flag=1;
    }
    var gpsID = JSONObject[i].id;
    var reg = JSONObject[i].register_number;
    var vehicle_id = JSONObject[i].vehicle_id;
    var vehicle_name = JSONObject[i].vehicle_name;
    var loc = new google.maps.LatLng(lat, lng);
    var mode = JSONObject[i].mode;
    var encrypt_gps_id = JSONObject[i].encrypt_gps_id;
    var color = "";
    var vehicle_status = "";
    if (mode == 'M') {
    car_color = "#84b752";
    vehicle_status = "Moving";
    } else if (mode == 'H') {
    car_color = "#69b4b9";
    vehicle_status = "Halt"
    } else if (mode == 'S') {
    car_color = "#858585";
    vehicle_status = "Sleep"
    } else {
    car_color = "#c41900";
    vehicle_status = "Offline"
    }

    /*var title = '<div id="content" style="width:150px;">' +
    '<span style="margin-right:5px;"><i class="fa fa-circle" style="color:'
    + car_color + ';" aria-hidden="true"></i></span>' + vehicle_status +
    '<div style="color:#000;font-weight:600;margin-top:5px;" ><span style="padding:20px;"><i>'
    + vehicle_name + '</i></span></div>' +
    '<div style="padding-top:5px; padding-left:16px;"><i class="fa fa-edit"></i><span style="margin-right:5px;">:</span>'
     + reg + ' </div>' +
    '<a href=/vehicles/'
    + vehicle_id +
    '/location class="btn btn-xs btn btn-warning" title="Location" style="background-color:#fff;padding-right:40px;"><i class="fa fa-map-marker" style="color:#000;font-size: 18px;"></i></a>  <a href="/alert" class="btn btn-xs btn btn-warning" title="Alerts" style="background-color:#fff;"><i class="fa fa-warning" style="color:#000;font-size: 18px;"></i></a>' +
    '</div>';*/

     var title = '<div style="width:100%;float:left;">'+
    '<div class="text-center mb-4" style="margin:0 0 1.5rem .5rem!important">'+
    '<h3 class="h3 mb-3 font-weight-normal" style="text-align: left!important;font-size:1.25rem;margin-bottom:0!important;text-transform: uppercase ">'
    + vehicle_name +

    '<p style="text-align:left!important;margin-bottom: -1rem!important;font-size:.9rem!important"><code>'
    + vehicle_status +
    '</code><br><img src="assets/images/plate.png" width=30 height=30><b>&nbsp;Vehicle Number:-</b> '
    + reg +'</p>'+
    '</div>'+


    '<a href="/vehicle/'+ encrypt_gps_id +'/alert" ><button class="btn-pop type="submit" style="margin-right:2%;margin-left:3%;background-color:#f0b100;border-radius:5px"><img src="assets/images/alarm.svg" width=13 height=13>Alerts</button></a>'+
    '<a href="/vehicles/'
    + vehicle_id +
    '/location"><button class="btn-pop type="submit" style="margin-right:1%;background-color:#f0b100;border-radius:5px"><img src="assets/images/live-track.svg" width=13 height=13>Track</button></a>'+
    '<a href="/vehicles/'+ vehicle_id +'/playback-page" target="blank">'+
    '<button class="btn-pop type="submit" style="background-color:#f0b100;border-radius:5px"><img src="assets/images/reply.svg" width=13 height=13>Replay</button></div></a>';


    var path = JSONObject[i].vehicle_svg;
    var scale = JSONObject[i].vehicle_scale;
    var fillOpacity = JSONObject[i].opacity;
    var strokeWeight = JSONObject[i].strokeWeight;
    addMarker(loc, title, car_color, path, scale, fillOpacity, strokeWeight, gpsID);
    if (track_flag != 0) {
    addVehicleToVehicleList(vehicle_name, reg, gpsID);
    }
    }
    setMapOnAll(map);
  }

}

function addMarker(location, title, car_color, path, scale, fillOpacity, strokeWeight, gpsID) {
  var icon = { // car icon
    path: path,
    scale: scale,
    fillColor: car_color, //<-- Car Color, you can change it
    fillOpacity: fillOpacity,
    strokeWeight: strokeWeight,
    anchor: new google.maps.Point(0, 5),
    size: new google.maps.Size(60,30.26),
  };
   var marker = new google.maps.Marker({
    position: location,
    title: "",
    icon: icon,
    gpsid:gpsID
  });

  var infowindow = new google.maps.InfoWindow();
  google.maps.event.addListener(marker, 'mouseover', function() {
    // alert(vehicle_id);
    getVehicle(gpsID);
    infowindow.setContent(title);
    infowindow.open(map, this);
    map_popup = 0;
  });

  google.maps.event.addListener(marker, 'click', function() {
    // alert(vehicle_id);
    getVehicle(gpsID);
    infowindow.setContent(title);
    infowindow.open(map, this);
    if (map_popup == 1) {
    map_popup = 0;
    } else {
    map_popup = 1;
    }
  });

  google.maps.event.addListener(marker, 'mouseout', function() {
    if (map_popup == 0) {
      infowindow.close(map, this);
    }
  });
  markers.push(marker);
}
function setMapOnAll(map) {
  for (var i = 0; i < markers.length; i++) {
    markers[i].setMap(map);
  }
}
function selectVehicleTrack(res) {

  // deleteMarkers();
  map.panTo(new google.maps.LatLng(res.lat, res.lon));
  map.setZoom(18);
  flag=1;
  // map.setMax(18);
  if(circleStatus==1){
    cityCircle.setMap(null);
  }
  refesh_flag=1;
  redarLocationSelectVehicle(res.lat,res.lon,0.08);
}

$(".vehicle_gps_id").click(function() {
  var url = '/dashboard-track';
  var gps_id = this.value;
  // alert(gps_id);
  var data = {
    gps_id: gps_id
  };
  backgroundPostData(url, data, 'selectVehicleTrack', {
    alert: false
  });
});


function getVehicleTrack(gps_id){
  var url = '/dashboard-track';
  var data = {
    gps_id: gps_id
  };

  backgroundPostData(url, data, 'selectVehicleTrack', {
    alert: false
  });
}

function locationSearch()
{
  document.getElementById('map_refresh_button').style.display="block";
  var place_name = $('#search_place').val();
  radius = $('#search_radius').val();
  if(radius!="KM"){
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({
      'address': place_name
    }, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        removeCircleFromMap();
        track_flag = 1;
        $('#vehicle_card_cover').empty();
        var lat = results[0].geometry.location.lat();
        var lng = results[0].geometry.location.lng();
        map.panTo(new google.maps.LatLng(lat, lng));
        // map.setZoom(12);
        var url = '/location-search';
        var data = {
          lat: lat,
          lng: lng,
          radius: radius
        };
        backgroundPostData(url, data, 'searchLocation', {
          alert: false
        });
        redarLocation(lat, lng, radius);
      }else{
          alert("Please enter a valid location");
      }
    });
  }else{
    alert("Please select radius");
  }
  return false;
}

function moving(vehicle_mode)
{
  if(selected_vehicle_mode == vehicle_mode)
  {
    window.location.reload(true);
  }
  else
  {
    selected_vehicle_mode = vehicle_mode;
  }

  track_flag = 1;
  $('#vehicle_card_cover').empty();
  var url = 'dashboard-track-vehicle-mode';
  var data = {
  vehicle_mode: vehicle_mode
  };
  backgroundPostData(url, data, 'selectVehicleModeTrack', {
  alert: false
  });
}

function selectVehicleModeTrack(res) {
 deleteMarkers();
 // remove green circle if already rendered
 if( typeof cityCircle != 'undefined' )
 {
  // remove circle only for selected vehicle
  if( cityCircle.tag == 'highligt_selected_vehicle')
  {
    cityCircle.setMap(null);
  }
 }
 flag = 0;
 vehicleTrack(res);

}

function deleteMarkers() {
 clearMarkers();
 markers = [];
}

function clearMarkers() {
 setMapOnAll(null);
}

function addVehicleToVehicleList(vehicle_name, reg, gpsID) {
 var vehicleData = '<div class="border-card">' +
  '<div class="card-type-icon with-border">' +
  '<input type="radio" id="radio"  class="vehicle_gps_id" name="radio" onclick="getVehicle(' + gpsID + '); getVehicleTrack(' + gpsID + '); " value="' + gpsID + '">' +
  '</div>' +
  '<div class="content-wrapper">' +
  '<div class="label-group fixed">' +
  '<p class="title">' +
  '<span><i class="fa fa-car"></i></span>' +
  '</p>' +
  '<p class="caption" id="vehicle_name">' + vehicle_name + '</p>' +
  '</div>' +
  '<div class="min-gap"></div>' +
  '<div class="label-group">' +
  '<p class="title">' +
  '<span><i class="fas fa-arrow-alt-circle-left"></i></span>' +
  '</p>' +

  '<p class="caption" id="register_number">' + reg + '</p>' +
  '</div>' +
  '<div class="min-gap"></div>' +
  '<div class="label-group">' +
  '<p class="title">' +
  '<p class="caption"></p>' +
  '</div>' +

  '</div>' +
  '</div>';

 $("#vehicle_card_cover").append(vehicleData);


}


function searchLocation(res) {

 if (res.status == "success") {
  deleteMarkers();
  flag = 0;
  vehicleTrack(res);
  setMapZoom(radius);
 } else {
  setMapZoom(radius);
  alert('No vehicle found in this location');
 }
  // map updated. display refresh button
  document.getElementById('map_refresh_button').style.display="block";
}


function redarLocation(lat, lng, radius) {
 if(circleStatus==1){
   cityCircle.setMap(null);
    if(radarStatus==1){
     myGoogleRadar.hidePolygon();
   }
 }
 var radius_in_meter = radius * 1000;
 var latlng = new google.maps.LatLng(lat, lng);
 var sunCircle = {
  strokeColor: "#b84930",
  tag:'highligt_selected_location',
  strokeOpacity: 0.8,
  strokeWeight: 2,
  fillColor: "#b84930",
  fillOpacity: 0.35,
  map: map,
  center: latlng,
  radius: radius_in_meter // in meters
 };
 cityCircle = new google.maps.Circle(sunCircle);
 var opts = {
  lat: lat,
  lng: lng
 };
 myGoogleRadar = new GoogleRadar(map, opts);

 // init a RadarPolygon
 opts = {
  angle: 10,
  time: 60,
  radius: radius
 };
 myGoogleRadar.addRadarPolygon(opts);
 circleStatus=1;
 radarStatus=1;
}


function redarLocationSelectVehicle(lat, lng, radius) {
 if(circleStatus==1){
   cityCircle.setMap(null);
   if(radarStatus==1){
     myGoogleRadar.hidePolygon();
   }
 }

 var radius_in_meter = radius * 1000;
 var latlng = new google.maps.LatLng(lat,lng);

 var sunCircle = {
  strokeColor: "#408753",
  tag:'highligt_selected_vehicle',
  strokeOpacity: 0.8,
  strokeWeight: 2,
  fillColor: "#408753",
  fillOpacity: 0.35,
  map: map,
  center: latlng,
  // minZoom: 17,
  //   maxZoom: 17,
  radius: radius_in_meter // in meters
 };
 cityCircle = new google.maps.Circle(sunCircle);


 circleStatus=1;
}

function setMapZoom(radius) {
 if (radius == 10) {
  zoom_size = 11;
 } else if (radius == 30) {
  zoom_size = 10;
 } else if (radius == 50) {
  zoom_size = 9;
 } else if (radius == 75) {
  zoom_size = 8;
 } else if (radius == 100) {
  zoom_size = 8;
 } else {
  var zoom_size = 8;
 }
 map.setZoom(zoom_size);
}

// ------------------------------------------
function removeCircleFromMap(){

}
// -------------------------------------------
$(document).ready(function() {
 $('st-actionContainer').launchBtn({
  openDuration: 500,
  closeDuration: 300
 });
});

$('.cover_track_data').click(function(){
   $('.track_status').css('display','none');
});

function refreshPage()
{
  document.getElementById('refresh_button').innerHTML = "Please wait...";
  window.location.reload(true);
}