$(document).ready(function () {
    var from_date = document.getElementById('fromDate').value;
    var to_date = document.getElementById('toDate').value;
    var data = {'from_date':from_date , 'to_date':to_date};
    callBackDataTable(data);
});


    function check()
    {
        if(document.getElementById('fromDate').value == ''){
            alert('Please select From date');
        }else if(document.getElementById('toDate').value == ''){
            alert('Please select To date');
        }else{
            var from_date = document.getElementById('fromDate').value;
            var to_date = document.getElementById('toDate').value;
        var data = {'from_date':from_date , 'to_date':to_date};
        callBackDataTable(data);
        }
       
    }


function callBackDataTable(data=null){
    
    // var  data = {
    //      // dealer : $('meta[name = "dealer"]').attr('content'),
    //        // sub_dealer:$('meta[name = "client"]').attr('content')
    //       from_date : document.getElementById('fromDate').value,
    //      to_date : document.getElementById('toDate').value    
    // }; 
    // console.log(data);
    $("#dataTable").DataTable({
        bStateSave: true,
        bDestroy: true,
        bProcessing: true,
        serverSide: true,
        deferRender: true,
        order: [[1, 'desc']],
        ajax: {
            url: 'log-report-list',
            type: 'POST',
            data: data,
            headers: {
                'X-CSRF-Token': $('meta[name = "csrf-token"]').attr('content')
            }
        },
        createdRow: function ( row, data, index ) {
            if ( data['deleted_at'] ) {
                $('td', row).css('background-color', 'rgb(243, 204, 204)');
            }
        },       
        fnDrawCallback: function (oSettings, json) {
        },
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: true, searchable: false},         
            {data: 'gps.imei', name: 'gps.imei',searchable: false},           
            {data: 'status', name: 'status', orderable: false},
            {data: 'user.username', name: 'user.username',searchable: false},
            {data: 'created_at', name: 'created_at',searchable: false},         
            
        ],
        
        aLengthMenu: [[25, 50, 100, -1], [25, 50, 100, 'All']]
    });
}
