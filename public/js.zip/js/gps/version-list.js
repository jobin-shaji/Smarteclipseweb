$("#versionClick").click(function(){
$('#versionModal').modal('show');
});
    