$(document).ready(function () {
    callBackDataTable();
});


function callBackDataTable(){
    var  data = {
    
    }; 

    $("#dataTable").DataTable({
        bStateSave: true,
        bDestroy: true,
        bProcessing: true,
        serverSide: true,
        deferRender: true,
        order: [[1, 'desc']],
        ajax: {
            url: 'gps-trader-list',
            type: 'POST',
            data: {
                'data': data
            },
            headers: {
                'X-CSRF-Token': $('meta[name = "csrf-token"]').attr('content')
            }
        },
        createdRow: function ( row, data, index ) {
            if ( data['deleted_at'] ) {
                $('td', row).css('background-color', 'rgb(243, 204, 204)');
            }
        },
       
        fnDrawCallback: function (oSettings, json) {

        },
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false},
            {data: 'gps.imei', name: 'gps.imei', orderable: false},
            {data: 'gps.serial_no', name: 'gps.serial_no', orderable: false},
            {data: 'gps.batch_number', name: 'gps.batch_number', orderable: false},
            {data: 'gps.model_name', name: 'gps.model_name', orderable: false},
            {data: 'client', name: 'client', orderable: false},
            {data: 'status', name: 'status', orderable: false},
            {data: 'action', name: 'action', orderable: false, searchable: false},  
        ],
        
        aLengthMenu: [[25, 50, 100, -1], [25, 50, 100, 'All']]
    });
    var table = $('#dataTable').DataTable();
    table.search('').draw();
}

function deactivateGpsStatusFromTrader(gps_id){
    if(confirm('Are you sure to deactivate this device?')){
        var url = 'gps-trader-status/deactivate';
        var data = {
            id : gps_id
        };
        backgroundPostData(url,data,'callBackDataTables',{alert:true});  
    }
}
function activateGpsStatusFromTrader(gps_id){
    if(confirm('Are you sure to activate this device?')){
        var url = 'gps-trader-status/activate';
        var data = {
            id : gps_id
        };
        backgroundPostData(url,data,'callBackDataTables',{alert:true});  
    }
}


