@extends('layouts.eclipse') 
@section('content')
<div class="page-wrapper">
	<div class="card-body">
	    <div class="pad margin no-print">
	      <div class="callout callout-danger" style="margin-bottom: 0!important;">
	      Geofence does not exist !!!
	      </div>
	    </div>
	</div>
</div>
@endsection