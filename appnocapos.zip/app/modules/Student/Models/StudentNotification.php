<?php

namespace App\Modules\Student\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class StudentNotification extends Model
{
    use SoftDeletes;   
    protected $fillable=[
		'mobile','message','client_id','type','date'
	];
   
}
