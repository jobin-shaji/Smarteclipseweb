@extends('layouts.eclipse') 
@section('title')
  Change Password
@endsection
@section('content')

<div class="page-wrapper_new">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item active" aria-current="page"><a href="/home">Home</a>/Change Password</li>
      <b>Change Password</b>
    </ol>
    @if(Session::has('message'))
      <div class="pad margin no-print">
        <div class="callout {{ Session::get('callout-class', 'callout-success') }}" style="margin-bottom: 0!important;">
            {{ Session::get('message') }}  
        </div>
      </div>
    @endif  
  </nav>
    <div class="row">
      <div class="col-lg-6 col-md-12">
        <div id="zero_config_wrapper" class="container-fluid dt-bootstrap4">  <div class="row">
          <div class="col-sm-12">
            <h4 class="page-header">
            </h4>
              <form  method="POST" action="{{route('root.update.password.p',$user->id)}}">
                {{csrf_field()}}
                  <div class="row">
                    <div class="col-md-6">
                      <input type="hidden" name="id" value="{{$user->id}}">
                        <div class="form-group has-feedback">
                          <label class="srequired">New Password</label>
                            <input type="password" class="form-control {{ $errors->has('password') ? ' has-error' : '' }}" placeholder="New Password" name="password" pattern= '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*)(=+\/\\~`-]).{8,20}$' title='Password must contains minimum 8 characters with at least one uppercase letter, one lowercase letter, one number and one special character' maxlength='20' required>
                        </div>
                        <div class="form-group has-feedback">
                          <label class="srequired">Confirm password</label>
                            <input type="password" class="form-control {{ $errors->has('password') ? ' has-error' : '' }}" placeholder="Retype password" name="password_confirmation" pattern= '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*)(=+\/\\~`-]).{8,20}$' title='Password must contains minimum 8 characters with at least one uppercase letter, one lowercase letter, one number and one special character' maxlength='20' required>
                            @if ($errors->has('password'))
                              <span class="help-block">
                                <strong class="error-text">{{ $errors->first('password') }}</strong>
                              </span>
                            @endif 
                        </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3 ">
                      <button type="submit" class="btn btn-primary btn-md form-btn ">Update</button>
                    </div>
                  </div>
              </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
 
<div class="clearfix"></div>


@endsection