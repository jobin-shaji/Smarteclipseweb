<?php
namespace App\Modules\Root\Models;
use Illuminate\Database\Eloquent\Model;

class ServiceLevelAgreement extends Model
{
  
 
}
