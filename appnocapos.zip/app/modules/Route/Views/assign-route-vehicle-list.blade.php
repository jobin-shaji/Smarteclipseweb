@extends('layouts.eclipse')
@section('title')
  All Routes
@endsection
@section('content')

<div class="page-wrapper_new">
   <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page"><a href="/home">Home</a>/Assign Route</li>
        <b>Assign Route</b>
     </ol>
    </nav>
 
 <div class="container-fluid">
    <div class="card-body">
      <div class="table-responsive">
        <div id="zero_config_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">                     
          <div class="row">
            <div class="col-sm-12">
              <div class="panel-heading">
                        <div class="cover_div_search">
                        <div class="row">
                          <div class="col-lg-2 col-md-3"> 
                           <div class="form-group">
                            <label>Vehicle</label>                          
                            <select class="form-control select2" data-live-search="true" title="Select Vehicle" id="vehicle" name="vehicle">
                              <option value="">select</option>
                              @foreach ($vehicles as $vehicles)
                              <option value="{{$vehicles->id}}" @if($vehicles->is_returned == 1){{"disabled"}} @endif>{{$vehicles->register_number}}@if($vehicles->is_returned == 1){{" -- Returned"}} @endif</option>
                              @endforeach  
                            </select>
                          </div>
                          </div>
                          <div class="col-lg-2 col-md-3"> 
                           <div class="form-group">                      
                            <label>Route</label>                          
                            <select class="form-control select2" data-live-search="true" title="Select Route" id="vehicle_route" name="vehicle_route" >
                              <option value="">Select</option>
                              @foreach ($routes as $route)
                              <option value="{{$route->id}}">{{$route->name}}</option>
                              @endforeach  
                            </select>
                          </div>
                          </div>
                           <div class="col-lg-2 col-md-3"> 
                          <div class="form-group">                    
                            <label> From Date</label>
                              <input type="text" class="date_expiry form-control" id="fromDate" name="fromDate" onkeydown="return false">
                          </div>
                        </div>
                          <div class="col-lg-2 col-md-3"> 
                          <div class="form-group">                    
                            <label> To date</label>
                             <input type="text" class="date_expiry form-control" id="toDate" name="toDate" onkeydown="return false">
                          </div>
                          </div>
                           <div class="col-lg-3 col-md-3 pt-4">
                           <div class="form-group">          
                            <button style="margin-top: 19px;" class="btn btn-sm btn-info btn4 dwnld" onclick="selectRoute()">Route Schedule </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
              <table class="table table-hover table-bordered  table-striped datatable" style="width:100%;text-align: center;" id="dataTable">
                <thead>
                  <tr>
                      <th>SL</th>
                      <th>Route Name</th>
                      <th >Vehicle</th>
                      <th >Registration Number</th>
                      <th >From Date</th>

                      <th >To date</th>
                      <th >Action</th>


                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>               
  </div>
 </div>


@endsection

  @section('script')
    <script src="{{asset('js/gps/assign-route-vehicle-list.js')}}"></script>
  @endsection