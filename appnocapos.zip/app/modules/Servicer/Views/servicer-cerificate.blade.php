 @extends('layouts.eclipse')
@section('title')
    Assign Servicer
@endsection
@section('content')
<STYLE type="text/css">

body {margin-top: 0px;margin-left: 0px;}

#page_1 {position:relative; overflow: hidden;margin: 10px 0px 5px 0px;padding: 3px;border: 1px solid;width: 716px;height: 942px;}

#page_1 #p1dimg1 {position:absolute;top:0px;left:5px;z-index:-1;width:714px;height:1000px;}
#page_1 #p1dimg1 #p1img1 {width:714px;height:1000px;}




.dclr {clear:both;float:none;height:1px;margin:0px;padding:0px;overflow:hidden;}

.ft0{font: bold 16px 'Calibri';line-height: 19px;}
.ft1{font: 1px 'Calibri';line-height: 1px;}
.ft2{font: bold 15px 'Calibri';line-height: 18px;}
.ft3{font: bold 16px 'Calibri';text-decoration: underline;line-height: 19px;}
.ft4{font: 16px 'Calibri';line-height: 19px;}
.ft5{font: 16px 'Times New Roman';line-height: 19px;}

.p0{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p1{text-align: right;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p2{text-align: left;padding-left: 250px;margin-top: 27px;margin-bottom: 0px;}
.p3{text-align: left;padding-left: 50px;margin-top: 13px;margin-bottom: 0px;}
.p4{text-align: left;padding-left: 50px;margin-top: 12px;margin-bottom: 0px;}
.p5{text-align: left;padding-left: 245px;margin-top: 25px;margin-bottom: 0px;}
.p6{text-align: left;padding-left: 50px;margin-top: 24px;margin-bottom: 0px;}
.p7{text-align: left;padding-left: 50px;margin-top: 13px;margin-bottom: 0px;}
.p8{text-align: left;padding-left: 50px;margin-top: 13px;margin-bottom: 0px;}
.p9{text-align: justify;padding-left: 49px;padding-right: 49px;margin-top: 13px;margin-bottom: 0px;text-indent: 43px;}
.p10{text-align: left;padding-left: 338px;margin-top: 4px;margin-bottom: 0px;}
.p11{text-align: left;padding-left: 48px;margin-top: 25px;margin-bottom: 0px;}
.p12{text-align: left;padding-left: 48px;margin-top: 12px;margin-bottom: 0px;}
.p13{text-align: left;padding-left: 48px;margin-top: 13px;margin-bottom: 0px;}
.p14{text-align: left;padding-left: 91px;margin-top: 13px;margin-bottom: 0px;}
.p15{text-align: left;padding-left: 50px;margin-top: 5px;margin-bottom: 0px;}
.p16{text-align: right;padding-right: 10px;margin-top: 30px;margin-bottom: 0px;}

.td0{padding: 0px;margin: 0px;width: 300px;vertical-align: bottom;}
.td1{padding: 0px;margin: 0px;width: 153px;vertical-align: bottom;}

.tr0{height: 20px;}
.tr1{height: 24px;}

.t0{width: 655px;margin-left: 91px;margin-top: 3px;font: bold 16px 'Calibri';}

</STYLE>
<div class="page-wrapper page-wrapper-root page-wrapper_new">
<div class="page-wrapper-root1">
          
      <div class="container-fluid">                    
        <div class="card-body">
          <div class="table-responsive">

              <div class="download_button pull-right">
                      <a href="{{ url('/') }}/job-complete/{{$id}}/downloads">
                        <button class="btn"><i class="fa fa-download"></i>Download</button>
                      </a>
                    </div>
            <TABLE cellpadding=0 cellspacing=0 class="t0">
<TR>
  <TD class="tr0 td0"><P class="p0 ft0" style="margin-left: -10px;">SUB DEALER/OEM ICON</P></TD>
  <TD class="tr0 td1"><P class="p1 ft0">ADDRESS WITH</P></TD>
</TR>
<TR>
  <TD class="tr1 td0"><P class="p0 ft1">&nbsp;</P></TD>
  <TD class="tr1 td1"><P class="p1 ft2">PHONE NUMBER AND MAIL ID</P></TD>
</TR>
</TABLE>

             
        
      </div>
    </div>            
  </div>
</div>




 


 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<META http-equiv="X-UA-Compatible" content="IE=8">
<TITLE></TITLE>
<META name="generator" content="BCL easyConverter SDK 5.0.140">

</HEAD>

<BODY>
<DIV id="page_1">
<DIV id="p1dimg1">



<DIV class="dclr"></DIV>

<P class="p2 ft3">INSTALLATION CERTIFICATE</P>
<P class="p3 ft4">DATE:</P>
<P class="p4 ft4">DOCUMENT NUMBER:</P>
<P class="p5 ft4">TO WHOMSOVER IT MAY CONCERN</P>
<P class="p6 ft4">Dear Sir,</P>
<P class="p7 ft4">Sub: Installation of Smart Eclipse Manufactured by VST Mobility solutions, Kochi</P>
<P class="p8 ft4">Ref:ARAI certification number</P>
<P class="p9 ft4">We VST Mobility Solution/SUB Dealer name , manufacturers/Dealers of AIS 140 ARAI certified GPS solutions hereby confirm that we have completed the installation of GPS device for the following vehicle as mentioned below,</P>

<P class="p4 ft4">Vehicle Engine Number:</P>
<P class="p3 ft4">Vehicle Chassis number:</P>
<P class="p3 ft4">Vehicle Make & Model:</P>
<P class="p3 ft4">Vehicle Reg No:</P>
<P class="p4 ft4">VTU model:</P>
<P class="p3 ft4">IMEI number:</P>
<P class="p3 ft4">Owner name;</P>
<P class="p3 ft4">Owner address;</P>
<P class="p4 ft4">Mobile no:</P>
<P class="p3 ft4">Email:</P>
<P class="p11 ft4">Yours truly,</P>
<P class="p12 ft4">OEM/dealer name</P>
<P class="p13 ft4">Signature and name of service Engineer</P>
<P class="p14 ft4"><NOBR>-------------------------------------Tamper</NOBR> <NOBR>here----------------------------------------------------------</NOBR></P>
<P class="p15 ft5">CUSTOMER FEEDBACK:</P>
<P class="p16 ft4">NAME AND SIGNATURE OF CUSTOMER</P>
</DIV>
</BODY>
</HTML>
@endsection