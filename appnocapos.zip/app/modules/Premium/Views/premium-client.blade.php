@extends('layouts.eclipse')
@section('title')
  Go Premium
@endsection
@section('content')
@section('pre-css')
  <link href="{{asset('css/style.min2.css')}}" rel="stylesheet">
@endsection

<body>
<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4" style="color:#b2bb00">Go Premium</h1>
</div>

<div class="container">
  <div class="card-deck mb-3 text-center">
    <div class="card mb-3 shadow-sm">
      <div style="height:72px">
        <!-- <img src="{{url('/')}}/premium/car1.jpg" class="card-img-top" alt="..." style="width: 7rem;margin: 3% auto"> -->
      <!--   <div class="card-body">
          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        </div> -->
      </div>
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">Freebies </h4>
      </div>
      <div class="card-body">
        <!-- <h1 class="card-title pricing-card-title">$15 <small class="text-muted">/ mo</small></h1> -->
        <ul class="list-unstyled mt-3 mb-4">
          <li><i class="fas fa-mobile-alt"></i>Mobile application</li>
          <li><i class="far fa-caret-square-left"></i>Route playback history(1 Month)</li> 
          <li><i class="far fa-map"></i>Point of interest</li>
          <li><img src="{{url('/')}}/assets/images/geofence.png" style="margin:0 2%">Geofence(2 Geofence)</li> 
          <li><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Emergency alerts</li>

      <!--   <?php
        $url=url()->current();
        if (strpos($url, "rayfleet") == true) {  ?>
          <li style="height:24px"><i class="fa fa-qar" aria-hidden="true"></i> </li> 
        <?php } 
        else { ?>
          <li style="height:24px"><i class="fa fa-inr" aria-hidden="true"></i>Price: After 1 year 1700+Tax </li> 
        <?php } ?>  -->
          <li style="height:24px"></li> 
          <li style="height:24px"></li> 
          <li style="height:24px"></li> 
          <li style="height:24px"></li> 
          <li style="height:24px"></li> 
           <li style="height:24px"></li> 
          <li style="height:33px"></li> 
        </ul>
      <?php
      $url=url()->current();
      $rayfleet_key="rayfleet";
      $eclipse_key="eclipse";
        if (strpos($url, $rayfleet_key) == true) {  ?>
          <!-- <h4 style="color: red"><u><b>After 1 Year</b></u></h4>
          <h6><b>Data charge:</b>  QAR </h6>
          <h6><b>Server & Software charge:</b></h6>
          <h6><i>(1 year validity)</i></h6> -->
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
          <!-- <h4 style="color: red"><u><b>After 1 Year</b></u></h4>
          <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
          <h6><b>Server & Software charge:</b>  ₹600 + Tax</h6>
          <h6><i>(1 year validity)</i></h6> -->
        <?php }
        else { ?>
          <!-- <h4 style="color: red"><u><b>After 1 Year</b></u></h4>
          <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
          <h6><b>Server & Software charge:</b>  ₹600 + Tax</h6>
          <h6><i>(1 year validity)</i></h6> -->
        <?php } ?> 
        <p>
          <br>
          <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
          <br>
          <a  data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
           Alert Reports (1 month history)
          </a>
        </p>
        <a data-toggle="collapse" href="#collapseExample"><img src="{{url('/')}}/assets/images/download.gif" width="20" height="30"></a>
        <div class="collapse" id="collapseExample">
          <div class="card card-body" style="margin:0!important">
          <ul class="list-unstyled mt-3 mb-4">
            <li><img src="{{url('/')}}/assets/images/braking.png" style="margin:0 2% 0 0">Harsh Braking Alert</li> 
            <li><img src="{{url('/')}}/assets/images/accelaration.png" style="margin:0 2% 0 0">Harsh Acceleration Alert</li>
            <li><img src="{{url('/')}}/assets/images/turning.png" style="margin:0 2% 0 0">Rash Turning Alert</li>
            <li><img src="{{url('/')}}/assets/images/box-open.png" style="margin:0 2% 0 0">GPS Box Opened Alert</li> 
            <li><img src="{{ url('/') }}/SVG-Icons/geofence-entry.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Entry Alert</li> 
            <li><img src="{{ url('/') }}/SVG-Icons/geofence-exit.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Exit Alert</li>
            <li><img src="{{url('/')}}/assets/images/connect-battery.png" style="margin:0 2% 0 0">Vehicle Battery Reconnect/ Connect back to main battery Alert</li> 
            <li><i class="fas fa-battery-quarter"></i>Low battery Alert</li>
            <li><img src="{{url('/')}}/assets/images/low-battery.png" style="margin:0 2% 0 0">Low battery removed Alert</li> 
            <li><img src="{{url('/')}}/assets/images/button.png" style="margin:0 2% 0 0">Emergency button wiredisconnect/wirecut Alert</li>
            <li><img src="{{url('/')}}/assets/images/disconnect.png" style="margin:0 2% 0 0">Disconnect from main battery Alert</li> 
            <li><img src="{{url('/')}}/assets/images/overspeed.png" style="margin:0 2% 0 0">Over speed Alert</li> 
            <li><img src="{{url('/')}}/assets/images/tilt.png" style="margin:0 2% 0 0">Tilt Alert</li> 
            <li><img src="{{url('/')}}/assets/images/impact.png" style="margin:0 2% 0 0">Impact Alert</li>
            <li><img src="{{url('/')}}/assets/images/geo-entry.png" style="margin:0 2% 0 0">Overspeed+ GF Entry Alert</li> 
            <li><img src="{{url('/')}}/assets/images/geo-exit.png" style="margin:0 2% 0 0">Overspeed + GF Exit Alert</li>
            <li><img src="{{url('/')}}/assets/images/location.png" style="margin:0 2% 0 0">Location Update Alert</li> 
            <li><img src="{{url('/')}}/assets/images/location-update.png" style="margin:0 2% 0 0">Location Update (history) Alert</li> 
            <li><img src="{{url('/')}}/assets/images/ignition-on.png" style="margin:0 2% 0 0">Alert – Ignition ON Alert</li> 
            <li><img src="{{url('/')}}/assets/images/ignition-off.png" style="margin:0 2% 0 0">Alert – Ignition OFF Alert</li> 
            <li><img src="{{url('/')}}/assets/images/state-on.png" style="margin:0 2% 0 0">Alert – Emergency state ON* Alert</li> 
            <li><img src="{{url('/')}}/assets/images/state-off.png" style="margin:0 2% 0 0">Alert – emergency State OFF Alert</li> 
            <li><img src="{{url('/')}}/assets/images/air.png" >Alert Over the air parameter change Alert</li> 
            
          </ul>
          </div>
        </div>
        <!-- <button type="button" class="btn btn-lg btn-block btn-primary">Try Now</button> -->
      </div>
    </div>
<div class="card mb-3 shadow-sm">
   <div style="height:72px">
 <!--  <img src="{{url('/')}}/premium/car2.jpg" class="card-img-top" alt="..." style="width:7rem;margin:8.5% auto"> -->
<!--   <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div> -->
</div>
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">Fundamental</h4>
      </div>
      <?php
        $url=url()->current();
        $rayfleet_key="rayfleet";
        $eclipse_key="eclipse";
        $encryption_id=encrypt(4);
        if (strpos($url, $rayfleet_key) == true) {  ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
        <?php }
        else { ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
      <?php } ?> 

      <div class="card-body">
        <!-- <h1 class="card-title pricing-card-title">$15 <small class="text-muted">/ mo</small></h1> -->
        <ul class="list-unstyled mt-3 mb-4">
          <li><i class="fas fa-mobile-alt"></i>Mobile application</li>
          <li><i class="far fa-map"></i>Point of interest</li>
          <li><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Emergency alerts</li>
          <li><img src="{{url('/')}}/assets/images/route.png" style="margin:0 2%">Route Deviation[4 routes]</li>
          <li><i class="far fa-caret-square-left"></i>Route playback history(2 Months)</li>
          <li><img src="{{url('/')}}/assets/images/geofence.png" style="margin:0 2%">Geofence(4 Geofences)</li>
          <li><i class="far fa-star"></i>Driver score</li>
          <li><img src="{{url('/')}}/assets/images/towing.png" style="margin:0 2%">Towing alert</li>
          <li><img src="{{url('/')}}/assets/images/radar.png" style="margin:0 2%">Radar</li>
           <li><img src="{{url('/')}}/assets/images/ac.png" height="15px" width="15px" style="margin:0 2%">AC Status</li>
          <li><i class="far fa-share-square"></i>Share in webapp</li>
          <li style="height:30px"></li> 
        </ul>
        <!-- <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
        <h6><b>Server & Software charge:</b>  ₹1700 + Tax</h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php
      $url=url()->current();
      $rayfleet_key="rayfleet";
      $eclipse_key="eclipse";
        if (strpos($url, $rayfleet_key) == true) {  ?>
          <!-- <h6><b>Data charge:</b> </h6>
        <h6><b>Server & Software charge:</b> </h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
          <!-- <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
        <h6><b>Server & Software charge:</b>  ₹1700 + Tax</h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php }
        else { ?>
        <!-- <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
        <h6><b>Server & Software charge:</b>  ₹1700 + Tax</h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php } ?> 
        <p>
          <br>
          <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
          <br>
  <a  data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">
   Alert Reports (2 months history)
  </a>
</p>
  <a data-toggle="collapse" href="#collapseExample1"><img src="{{url('/')}}/assets/images/download.gif" width="20" height="30"></a>
<div class="collapse" id="collapseExample1">
  <div class="card card-body" style="margin:0!important">
  <ul class="list-unstyled mt-3 mb-4">
          <li><img src="{{url('/')}}/assets/images/braking.png" style="margin:0 2% 0 0">Harsh Braking Alert</li>
          <li><img src="{{url('/')}}/assets/images/accelaration.png" style="margin:0 2% 0 0">Harsh Acceleration Alert</li>
          <li><img src="{{url('/')}}/assets/images/turning.png" style="margin:0 2% 0 0">Rash Turning Alert</li>
          <li><img src="{{url('/')}}/assets/images/box-open.png" style="margin:0 2% 0 0">GPS Box Opened Alert</li>
          <li><img src="{{ url('/') }}/SVG-Icons/geofence-entry.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Entry Alert</li>
          <li><img src="{{ url('/') }}/SVG-Icons/geofence-exit.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Exit Alert</li>
          <li><img src="{{url('/')}}/assets/images/connect-battery.png" style="margin:0 2% 0 0">Vehicle Battery Reconnect/ Connect back to main battery Alert</li>
          <li><i class="fas fa-battery-quarter"></i>Low battery Alert</li>
          <li><img src="{{url('/')}}/assets/images/low-battery.png" style="margin:0 2% 0 0">Low battery removed Alert</li>
          <li><img src="{{url('/')}}/assets/images/button.png" style="margin:0 2% 0 0">Emergency button wiredisconnect/wirecut Alert</li>
          <li><img src="{{url('/')}}/assets/images/disconnect.png" style="margin:0 2% 0 0">Disconnect from main battery Alert</li>
          <li><img src="{{url('/')}}/assets/images/overspeed.png" style="margin:0 2% 0 0">Over speed Alert</li>
          <li><img src="{{url('/')}}/assets/images/tilt.png" style="margin:0 2% 0 0">Tilt Alert</li>
          <li><img src="{{url('/')}}/assets/images/impact.png" style="margin:0 2% 0 0">Impact Alert</li>
          <li><img src="{{url('/')}}/assets/images/geo-entry.png" style="margin:0 2% 0 0">Overspeed+ GF Entry Alert</li>
          <li><img src="{{url('/')}}/assets/images/geo-exit.png" style="margin:0 2% 0 0">Overspeed + GF Exit Alert</li>
          <li><img src="{{url('/')}}/assets/images/location.png" style="margin:0 2% 0 0">Location Update Alert</li>
          <li><img src="{{url('/')}}/assets/images/location-update.png" style="margin:0 2% 0 0">Location Update (history) Alert</li>
          <li><img src="{{url('/')}}/assets/images/ignition-on.png" style="margin:0 2% 0 0">Alert – Ignition ON Alert</li>
          <li><img src="{{url('/')}}/assets/images/ignition-off.png" style="margin:0 2% 0 0">Alert – Ignition OFF Alert</li>
          <li><img src="{{url('/')}}/assets/images/state-on.png" style="margin:0 2% 0 0">Alert – Emergency state ON* Alert</li>
          <li><img src="{{url('/')}}/assets/images/state-off.png" style="margin:0 2% 0 0">Alert – emergency State OFF Alert</li>
          <li><img src="{{url('/')}}/assets/images/air.png" style="margin:0 2% 0 0">Alert Over the air parameter change Alert</li>
          </ul>
  </div>
</div>
        
      </div>
    </div>

    <div class="card mb-3 shadow-sm">
  <div style="height:72px">
  <!-- <img src="{{url('/')}}/premium/car3.jpg" class="card-img-top" alt="..."  style="width: 7rem;margin:1.5% auto;"> -->
<!--   <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div> -->
</div>
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">Superior</h4>
      </div>
      <?php
        $url=url()->current();
        $rayfleet_key="rayfleet";
        $eclipse_key="eclipse";
        $encryption_id=encrypt(4);
        if (strpos($url, $rayfleet_key) == true) {  ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
        <?php }
        else { ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
      <?php } ?>  
      
      <div class="card-body">
        <!-- <h1 class="card-title pricing-card-title">$0 <small class="text-muted">/ mo</small></h1> -->
       <ul class="list-unstyled mt-3 mb-4">
           <li><i class="fas fa-mobile-alt"></i>Mobile application</li>
          <li><i class="far fa-map"></i>Point of interest</li>
          <li><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Emergency alerts</li>
          <li><i class="far fa-star"></i>Driver score</li>
          <li><img src="{{url('/')}}/assets/images/towing.png" style="margin:0 2%">Towing alert</li>
          <li><img src="{{url('/')}}/assets/images/radar.png" style="margin:0 2%">Radar</li>
           <li><img src="{{url('/')}}/assets/images/ac.png" height="15px" width="15px" style="margin:0 2%">AC Status</li>
          <li><i class="far fa-share-square"></i>Share in webapp</li>
           <li><img src="{{url('/')}}/assets/images/route.png" style="margin:0 2%">Route Deviation[8 routes]</li>
           <li><i class="far fa-caret-square-left"></i>Route playback history(4 Months)</li>
          <li><img src="{{url('/')}}/assets/images/geofence.png" style="margin:0 2%">Geofence(8 Geofences)</li>
          <li><i class="far fa-file-alt"></i>Invoice</li>
          <li><img src="{{url('/')}}/assets/images/fuel.png" style="margin:0 2%">Fuel</li>
          <li><img src="{{url('/')}}/assets/images/client-logo.png" style="margin:0 2%">Client Logo</li> 
          <li><img src="{{url('/')}}/assets/images/immobilizer.png" style="margin:0 2%">Immobilizer</li>
          <li><i class="far fa-comment-dots"></i>Daily report as SMS </li>
          <li><i class="far fa-envelope"></i>Daily report summary to reg. mail</li>
          <li><img src="{{url('/')}}/assets/images/theft.png" style="margin:0 2%">Anti-Theft Mode</li>
          <li style="height:0"></li> 
        </ul>
        <!-- <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
        <h6><b>Server & Software charge:</b>  ₹2300 + Tax</h6>
        <h6><b>Immobilizer:</b>  ₹500 + Tax</h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php
      $url=url()->current();
      $rayfleet_key="rayfleet";
      $eclipse_key="eclipse";
        if (strpos($url, $rayfleet_key) == true) {  ?>
          <!-- <h6><b>Data charge:</b></h6>
        <h6><b>Server & Software charge:</b></h6>
        <h6><b>Immobilizer:</b></h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
          <!-- <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
        <h6><b>Server & Software charge:</b>  ₹2300 + Tax</h6>
        <h6><b>Immobilizer:</b>  ₹500 + Tax</h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php }
        else { ?>
        <!-- <h6><b>Data charge:</b>  ₹1700 + Tax</h6>
        <h6><b>Server & Software charge:</b>  ₹2300 + Tax</h6>
        <h6><b>Immobilizer:</b>  ₹500 + Tax</h6>
        <h6><i>(1 year validity)</i></h6> -->
        <?php } ?> 
        <p>
          <br>
          <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
          <br>
  <a  data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
   Alert Reports (4 months history)
  </a>
</p>
<a data-toggle="collapse" href="#collapseExample2"><img src="{{url('/')}}/assets/images/download.gif" width="20" height="30"></a>
<div class="collapse" id="collapseExample2">
  <div class="card card-body" style="margin:0!important">
  <ul class="list-unstyled mt-3 mb-4">
          <li><img src="{{url('/')}}/assets/images/braking.png" style="margin:0 2% 0 0">Harsh Braking Alert</li>
          <li><img src="{{url('/')}}/assets/images/accelaration.png" style="margin:0 2% 0 0">Harsh Acceleration Alert</li>
          <li><img src="{{url('/')}}/assets/images/turning.png" style="margin:0 2% 0 0">Rash Turning Alert</li>
          <li><img src="{{url('/')}}/assets/images/box-open.png" style="margin:0 2% 0 0">GPS Box Opened Alert</li>
          <li><img src="{{ url('/') }}/SVG-Icons/geofence-entry.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Entry Alert</li>
          <li><img src="{{ url('/') }}/SVG-Icons/geofence-exit.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Exit Alert</li>
          <li><img src="{{url('/')}}/assets/images/connect-battery.png" style="margin:0 2% 0 0">Vehicle Battery Reconnect/ Connect back to main battery Alert</li>
          <li><i class="fas fa-battery-quarter"></i>Low battery Alert</li>
          <li><img src="{{url('/')}}/assets/images/low-battery.png" style="margin:0 2% 0 0">Low battery removed Alert</li>
          <li><img src="{{url('/')}}/assets/images/button.png" style="margin:0 2% 0 0">Emergency button wiredisconnect/wirecut Alert</li>
          <li><img src="{{url('/')}}/assets/images/disconnect.png" style="margin:0 2% 0 0">Disconnect from main battery Alert</li>
          <li><img src="{{url('/')}}/assets/images/overspeed.png" style="margin:0 2% 0 0">Over speed Alert</li>
          <li><img src="{{url('/')}}/assets/images/tilt.png" style="margin:0 2% 0 0">Tilt Alert</li>
          <li><img src="{{url('/')}}/assets/images/impact.png" style="margin:0 2% 0 0">Impact Alert</li>
          <li><img src="{{url('/')}}/assets/images/geo-entry.png" style="margin:0 2% 0 0">Overspeed+ GF Entry Alert</li>
          <li><img src="{{url('/')}}/assets/images/geo-exit.png" style="margin:0 2% 0 0">Overspeed + GF Exit Alert</li>
          <li><img src="{{url('/')}}/assets/images/location.png" style="margin:0 2% 0 0">Location Update Alert</li>
          <li><img src="{{url('/')}}/assets/images/location-update.png" style="margin:0 2% 0 0">Location Update (history) Alert</li>
          <li><img src="{{url('/')}}/assets/images/ignition-on.png" style="margin:0 2% 0 0">Alert – Ignition ON Alert</li>
          <li><img src="{{url('/')}}/assets/images/ignition-off.png" style="margin:0 2% 0 0">Alert – Ignition OFF Alert</li>
          <li><img src="{{url('/')}}/assets/images/state-on.png" style="margin:0 2% 0 0">Alert – Emergency state ON* Alert</li>
          <li><img src="{{url('/')}}/assets/images/state-off.png" style="margin:0 2% 0 0">Alert – emergency State OFF Alert</li>
          <li><img src="{{url('/')}}/assets/images/air.png" style="margin:0 2% 0 0">Alert Over the air parameter change Alert</li>
          <li><img src="{{url('/')}}/assets/images/towing.png" style="margin:0 2% 0 0">Towing alert</li>
          <li><img src="{{url('/')}}/assets/images/fuel.png" style="margin:0 2% 0 0">Fuel filling alert</li>
          <li><img src="{{url('/')}}/assets/images/fuel-low.png" style="margin:0 2% 0 0">Sudden decrease in fuel level alert</li>
        </ul>
  </div>
</div>
         <!-- <button type="button" class="btn btn-lg btn-block btn-outline-primary">Pay Now</button> -->
      </div>

    </div>
    
    <div class="card mb-3 shadow-sm">
  <div style="height:72px">
 <!--  <img src="{{url('/')}}/premium/car4.jpg" class="card-img-top" alt="..."  style="width:7rem;margin:2% auto;"> -->
<!--   <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div> -->
</div>
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">PRO (White label)</h4>
      </div>
      <?php
        $url=url()->current();
        $rayfleet_key="rayfleet";
        $eclipse_key="eclipse";
        $encryption_id=encrypt(4);
        if (strpos($url, $rayfleet_key) == true) {  ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
        <?php }
        else { ?>
           <button type="button" class="btn"><a href="#" class="js-modal-show button-primary" onclick="popup()">Pay Now</a></button>
          <div class="l-modal is-hidden--off-flow js-modal-shopify">
            <div class="l-modal__shadow js-modal-hide"></div>
            <div class="c-popup l-modal__body">
              <a href="#" onclick="hide_popup()">X</a>
              <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
            </div>
          </div>
      <?php } ?> 
      
      <div class="card-body">
        <!-- <h1 class="card-title pricing-card-title">$0 <small class="text-muted">/ mo</small></h1> -->
        <ul class="list-unstyled mt-3 mb-4">
          <li><b>Everything in Superior +</b></li>
          <li><img src="{{url('/')}}/assets/images/route.png" style="margin:0 2%">Route Deviation[10 routes]</li>
          <li><i class="far fa-caret-square-left"></i>Route playback history(6 Months)</li>
          <li><img src="{{url('/')}}/assets/images/geofence.png" style="margin:0 2%">Geofence(10 Geofences)</li>
          <li><i class="fas fa-list"></i>Whitelist</li>
          <li><img src="{{url('/')}}/assets/images/www.png" style="margin:0 2%">Client domain</li>
          <li><img src="{{url('/')}}/assets/images/api.png" style="margin:0 2%">API access</li>
          <li><img src="{{url('/')}}/assets/images/design.png" style="margin:0 2%">Modify design(as per requirement)</li>
          <li><img src="{{url('/')}}/assets/images/custom.png" style="margin:0 2%">Custom features</li>
          <li><img src="{{url('/')}}/assets/images/database.png" style="margin:0 2%">Database backup</li>
          <li><img src="{{url('/')}}/assets/images/support.png" style="margin:0 2%">Privileged support</li>
          <li style="height:30px"></li> 
        </ul>
        <!-- <h6><b>Total charge:</b>  ₹500000 + Tax</h6> -->
        <?php
      $url=url()->current();
      $rayfleet_key="rayfleet";
      $eclipse_key="eclipse";
        if (strpos($url, $rayfleet_key) == true) {  ?>
          <!-- <h6><b>Total charge:</b></h6> -->
        <?php } 
        else if (strpos($url, $eclipse_key) == true) { ?>
         <!--  <h6><b>Total charge:</b>  ₹500000 + Tax</h6> -->
        <?php }
        else { ?>
       <!--  <h6><b>Total charge:</b>  ₹500000 + Tax</h6> -->
        <?php } ?> 
        <p>
          <br>
          <p class="blink_me" style="color: red">Contact your distributor for upgradation</p>
          <br>
  <a  data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample3">
   Alert Report (6 months history)
  </a>
</p>
<a data-toggle="collapse" href="#collapseExample3"><img src="{{url('/')}}/assets/images/download.gif" width="20" height="30"></a>
<div class="collapse" id="collapseExample3">
  <div class="card card-body" style="margin:0!important">
  <ul class="list-unstyled mt-3 mb-4">
          <li><img src="{{url('/')}}/assets/images/braking.png" style="margin:0 2% 0 0">Harsh Braking Alert</li>
          <li><img src="{{url('/')}}/assets/images/accelaration.png" style="margin:0 2% 0 0">Harsh Acceleration Alert</li>
          <li><img src="{{url('/')}}/assets/images/turning.png" style="margin:0 2% 0 0">Rash Turning Alert</li>
          <li><img src="{{url('/')}}/assets/images/box-open.png" style="margin:0 2% 0 0">GPS Box Opened Alert</li>
          <li><img src="{{ url('/') }}/SVG-Icons/geofence-entry.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Entry Alert</li>
          <li><img src="{{ url('/') }}/SVG-Icons/geofence-exit.png" style="margin:0 2% 0 0" height="20px" width="20px">Geofence Exit Alert</li>
          <li><img src="{{url('/')}}/assets/images/connect-battery.png" style="margin:0 2% 0 0">Vehicle Battery Reconnect/ Connect back to main battery Alert</li>
          <li><i class="fas fa-battery-quarter"></i>Low battery Alert</li>
          <li><img src="{{url('/')}}/assets/images/low-battery.png" style="margin:0 2% 0 0">Low battery removed Alert</li>
          <li><img src="{{url('/')}}/assets/images/button.png" style="margin:0 2% 0 0">Emergency button wiredisconnect/wirecut Alert</li>
          <li><img src="{{url('/')}}/assets/images/disconnect.png" style="margin:0 2% 0 0">Disconnect from main battery Alert</li>
          <li><img src="{{url('/')}}/assets/images/overspeed.png" style="margin:0 2% 0 0">Over speed Alert</li>
          <li><img src="{{url('/')}}/assets/images/tilt.png" style="margin:0 2% 0 0">Tilt Alert</li>
          <li><img src="{{url('/')}}/assets/images/impact.png" style="margin:0 2% 0 0">Impact Alert</li>
          <li><img src="{{url('/')}}/assets/images/geo-entry.png" style="margin:0 2% 0 0">Overspeed+ GF Entry Alert</li>
          <li><img src="{{url('/')}}/assets/images/geo-exit.png" style="margin:0 2% 0 0">Overspeed + GF Exit Alert</li>
          <li><img src="{{url('/')}}/assets/images/location.png" style="margin:0 2% 0 0">Location Update Alert</li>
          <li><img src="{{url('/')}}/assets/images/location-update.png" style="margin:0 2% 0 0">Location Update (history) Alert</li>
          <li><img src="{{url('/')}}/assets/images/ignition-on.png" style="margin:0 2% 0 0">Alert – Ignition ON Alert</li>
          <li><img src="{{url('/')}}/assets/images/ignition-off.png" style="margin:0 2% 0 0">Alert – Ignition OFF Alert</li>
          <li><img src="{{url('/')}}/assets/images/state-on.png" style="margin:0 2% 0 0">Alert – Emergency state ON* Alert</li>
          <li><img src="{{url('/')}}/assets/images/state-off.png" style="margin:0 2% 0 0">Alert – emergency State OFF Alert</li>
          <li><img src="{{url('/')}}/assets/images/air.png" style="margin:0 2% 0 0">Alert Over the air parameter change Alert</li>
          <li><img src="{{url('/')}}/assets/images/towing.png" style="margin:0 2% 0 0">Towing alert</li>
          <li><img src="{{url('/')}}/assets/images/fuel.png" style="margin:0 2% 0 0">Fuel filling alert</li>
          <li><img src="{{url('/')}}/assets/images/fuel-low.png" style="margin:0 2% 0 0">Sudden decrease in fuel level alert</li>
          <li><img src="{{url('/')}}/assets/images/report.png" style="margin:0 2% 0 0">Customized report</li>
        </ul>
  </div>
</div>
         <!-- <button type="button" class="btn btn-lg btn-block btn-outline-primary">Pay Now</button> -->
      </div>

    </div>
    
  </div>
</div>
<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> -->
</body>
@endsection
<script type="text/javascript">
function popup()
{
  $('.js-modal-shopify').toggleClass('is-shown--off-flow').toggleClass('is-hidden--off-flow');
}
function hide_popup(){
  $('.js-modal-shopify').toggleClass('is-shown--off-flow').toggleClass('is-hidden--off-flow');
}
</script>
<style type="text/css">
  .is-hidden--off-flow {
  opacity: 0;
  transition: all 0.2s ease-in-out;
  z-index: -10;   /* *1* */
  visibility: hidden;   /* *1* */
}


.l-modal {
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  height: 100%;
  margin: 0 auto;
  z-index: 2;
  text-align: center;
}

.l-modal__shadow {
  width: 100%;
  height: 100%;
  position: fixed;
  display: block;
  background: #161616;
  opacity: 0.92;
  z-index: -1;
  cursor: pointer;
}

.l-modal__body {
  position: relative;
  top: 50%;
  transform: translateY(-50%);
}

.c-popup {
    display: inline-block;
    text-align: center;
    background: white;
    max-width: 400px;
    width: 90%;
    line-height: 1.48;

    border-radius: 7px;
    background: #ccc;
}
.l-modal .l-modal__shadow {
    width: 100%;
    height: 100%;
    position: fixed;
    display: block;
    background: #0000008f;
    opacity: 0.92;
    z-index: -1;
    cursor: pointer;
}
.l-modal__body a{
    background: #b9b9b9;
    width: 100%;
    float: left;
    padding: 6px 0;
    color: #fff;
    font-weight: bold;
    text-align: right;
        font-size: 20px;
      border-top-left-radius: 7px;
    padding-right: 4%;
      border-top-right-radius:7px;
  }
.l-modal__body a:hover{
color: #000;
  }
.l-modal__body p{
float: left;
    text-align: center;
    width: 100%;
    font-size: 18px;
    padding: 22px 0;}

</style>