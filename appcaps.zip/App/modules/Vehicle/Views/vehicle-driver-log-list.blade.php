@extends('layouts.eclipse')
@section('title')
  Driver's Update History
@endsection
@section('content')

        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
<div class="page-wrapper_new">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            
            <li class="breadcrumb-item active" aria-current="page"><a href="/home">Home</a>/Driver's Update History</li>
            <b>Driver's Update History</b>
        </ol>
        @if(Session::has('message'))
        <div class="pad margin no-print">
            <div class="callout {{ Session::get('callout-class', 'callout-success') }}" style="margin-bottom: 0!important;">
              {{ Session::get('message') }}  
            </div>
        </div>
        @endif 
    </nav>
   
    <div class="container-fluid">
        <div class="card-body">
            <div class="table-responsive ">
                <div id="zero_config_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-hover table-bordered  table-striped datatable" style="width:100%;text-align: center;" id="dataTable">
                            <thead>
                                <tr>
                                    <th>SL.No</th>
                                    <th>Vehicle Name</th>
                                    <th>Registration Number</th>
                                    <th>From Driver</th>
                                    <th>To Driver</th>
                                    <th>Date & Time</th>
                                </tr>
                            </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
    <script src="{{asset('js/gps/vehicle-driver-log-list.js')}}"></script>
@endsection