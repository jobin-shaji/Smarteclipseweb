<?php 
namespace App\Modules\UserAlert\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\Alert\Models\Alert;
use App\Modules\Client\Models\Client;
use App\Modules\Alert\Models\AlertType;
use App\Modules\Alert\Models\UserAlerts;
use Illuminate\Support\Facades\Crypt;
use DataTables;
use DB;


class UserAlertController extends Controller {
    public function edit(Request $request)
    {        
        $user = \Auth::user();
        $client = Client::where('user_id', $user->id)->first();
        $root = $user->root;
        $alert_type = AlertType::all();
        $user_alert=array();
        $exclude            = [22, 23, 24];
        // $user_alert = UserAlerts::select('client_id', 'alert_id', 'status')
        // ->where('client_id',$client->id)
        // ->whereNotIn('alert_id', $exclude)
        // ->with('alertType:id,description,code')
        // ->get();


        $user_alert = DB::table('user_alerts')
            ->where('user_alerts.client_id', $client->id)
            ->whereNotIn('alert_id', $exclude)
            ->join('alert_types', 'user_alerts.alert_id', '=', 'alert_types.id')
            ->orderBy('alert_types.sort', 'ASC')
            ->select('user_alerts.alert_id as user_alert_id','user_alerts.status as status', 'alert_types.description as alert_name','alert_types.code as code')
            
            ->get();


        return view('UserAlert::alert-manager',['user_alert' => $user_alert]);
    }
    public function savealertManager(Request $request) 
    {       
        $user_id = \Auth::user()->id;
        $client = Client::select('user_id','id')->where('user_id', $user_id)->first();
         $alert = AlertType::select('id')->get();
        foreach ($alert as $alert) { 
            $user_item = UserAlerts::select('id','alert_id','client_id','status')->where('alert_id', $alert->id)->where('client_id', $client->id)->first();             
            if($user_item)
            { 
                $user_item->status =0;
                $user_item->save();
            }
        }
        $rules = $this->alertManagerRule();
        $this->validate($request, $rules);       
        $alert_array = $request->alert_id; 
        if($alert_array){
            foreach ($alert_array as $alert_id) {                           
                $user_alert = UserAlerts::select('id','alert_id','client_id','status')->where('alert_id', $alert_id)->where('client_id', $client->id)->first();                
                if($user_alert)
                {
                    $user_alert->status =1;
                    $user_alert->save();                         
                }                
            }
        }                      
        $request->session()->flash('message', 'Alert manager successfully updated!');
        $request->session()->flash('alert-class', 'alert-success');
        return redirect(route('alert.manager'));
    }
       // gps transfer rule
    public function alertManagerRule(){
        $rules = [
          'alert_id' => 'required'];
        return $rules;
    }
}