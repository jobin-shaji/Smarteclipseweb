<div style="margin-left:-21px!important">
<table border="1" cellpadding="0" style="margin:0 0;width:720px;margin-right:10px">
  <tbody>
    <tr style="width:700px;border:solid 1px #222;border-width:0 0 1px 0; position:absolute;">
      <td style="margin:12px 0 0 12px;border:none;width:150px">
        <img src="./images/vst-logo-New.png" width="120">
      </td>

      <td style="margin:12px 0 0 30px;width:120px;border:none;">
        <img src="./images/eclipse.png" width="130" >
      </td>

      <td style="margin:30px 0 0 ;width:120px;border:none">
       <img src="./images/make-in-india.png" width="88" height="48">
      </td>

      <td style="border:solid 1px #222;border-width:0 0 0 1px;width:100px;">

        <?php 
           $qr='Dealer:'.$role_details->name.'Address:'.$role_details->address.'Mobile:'.$user_details->mobile.'ScannedEmployee:'.$gps_transfer->scanned_employee_code.'OrderNumber:'.$gps_transfer->order_number.'InvoiceNumber:'.$gps_transfer->invoice_number;
        ?>
        <img src="data:image/png;base64, {!! base64_encode(QrCode::format('png')->size(100)->generate($qr)) !!} ">
      </td>

      </tr>

      <tr style=" width:710px; border:solid 1px #222;border-width:0 0 1px 0;position:absolute;">
        <td style="padding:12px 0;width:250px;margin:0 0 0 12px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:16px;font-weight:bolder;border:none;padding:0 0 0 12px">To:<br><br><span style="font-size:13px;word-wrap: break-word;">{{$role_details->name}},<br>
        {{$role_details->address}}</span>
        </td>
      </tr>
        <tr style="width:710px;border:solid 1px #222;border-width:0 0 1px 0;position:absolute;">
        <td style="margin:0 0 0 12px;width:250px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:13px;font-weight:bolder;padding:12px 0 12px 12px;border:none;">Mobile Number:{{$user_details->mobile}}
        </td>
   
        <td style="margin:0 0 0 12px;width:250px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:13px;font-weight:bolder;padding:12px 0 12px 12px;border:solid 1px #222;border-width:0 0 0 1px;word-wrap: break-word;">Scanned Employee Code:{{$gps_transfer->scanned_employee_code}}
        </td>
       
      </tr>

      <tr style="width:710px;border:solid 1px #222;border-width:0 0 1px 0;position:absolute;">
        <td style="margin:0 0 0 12px;width:250px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:13px;font-weight:bolder;padding:12px 0 12px 12px;border:none;">Order Number:{{$gps_transfer->order_number}}
        </td>
        <td style="margin:0 0 0 12px;width:250px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:13px;font-weight:bolder;padding:12px 0 12px 12px;border:solid 1px #222;border-width:0 0 0 1px; word-wrap: break-word;">Invoice Number:{{$gps_transfer->invoice_number}}
        </td>
      </tr>

      <tr style="position:absolute;" >
        <td style="margin:0 0 0 12px;width:250px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:16px;font-weight:bolder;padding:12px 0 12px 12px;border:none;" >From:<br><br><span style="font-size:13px;word-wrap: break-word;">{{$from_user_details->name}},<br>
          {{$from_user_details->address}},<br>
          Mobile Number: {{$user_details_data->mobile}}</span><br>
        </td>
        </td>
        <td style="margin:0 0 0 12px;width:250px;font-family:’Helvetica Bold’,Helvetica,’Arial Bold’,Arial,sans-serif;font-size:20px;font-weight:bolder;padding:12px 0 12px 12px;border:none;" >Certifications:<br><span> <img src="./images/certifications1.png" width="200" height="40"></span>
        </td>
      </tr>

  </tbody>
</table>
</div>

