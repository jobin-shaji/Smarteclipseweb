<table>
	<thead>
		<tr>
			<th>SLNo</th>
			<th>Vehicle</th>
			<th>AlertType</th>
			<th>Location</th>
			<th>DateTime</th>  
		</tr>
	</thead>
</table>














