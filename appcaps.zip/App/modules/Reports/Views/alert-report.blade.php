@extends('layouts.eclipse')
@section('title')
Alert Report
@endsection
@section('content')
<?php
    $perPage    = 15;
    $page       = isset($_GET['page']) ? (int) $_GET['page'] : 1;       
?>
  <div class="page-wrapper_new">
    <div class="page-breadcrumb">
      <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
          <b>  Alert Report</b>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="card-body">
        <div >
          <div id="zero_config_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 ">
            <div class="row">
              <div class="col-sm-12">
                <div class="col-md-12 col-md-offset-1">
                  <div class="panel panel-default">
                    <div >
                      <div class="panel-body">
                        <form method="get" action="{{route('alert-report-list')}}">
                          {{csrf_field()}}
                          <div class="panel-heading">
                            <div class="cover_div_search">
                              <div class="row">
                                <div class="col-lg-2 col-md-2">
                                  <div class="form-group">    
                                    <label>Vehicle</label>                      
                                    <select class="form-control selectpicker" required style="width: 100%" data-live-search="true" title="Select Vehicle" id="vehicle" name="vehicle">
                                    <option value="" selected="selected" disabled="disabled">Select</option>
                                    @foreach ($vehicles as $vehicle)                          
                                    <option value="{{$vehicle->id}}"  @if(isset($alertReports) && $vehicle->id==$vehicle_id){{"selected"}} @endif>{{$vehicle->name}}||{{$vehicle->register_number}}</option>
                                    @endforeach  
                                    </select>
                                  </div>
                                </div>
                                <div class="col-lg-2 col-md-2">
                                  <div class="form-group">    
                                    <label>Select Alert Type:</label>                 
                                    <select class="form-control selectpicker" style="width: 100%" data-live-search="true" title="Select Alert Type" id="alert" name="alert">
                                    <option value="" selected="selected" disabled="disabled">select</option>
                                    <option value="0" selected="selected">All</option>

                                    @foreach ($Alerts as $alert)
                                    <option value="{{$alert->id}}"   @if(isset($alertReports) && $alert->id==$alert_id){{"selected"}} @endif>{{$alert->description}}</option>
                                    @endforeach
                                    </select>
                                  </div>
                                </div>
                                <!-- -->
                                <div class="col-lg-2 col-md-2"> 
                                  <div class="form-group">                      
                                    <label> From Date</label>
                                    <div class="input-group date <?php if(\Auth::user()->hasRole('superior')){ echo 'datepickerSuperior'; }else if(\Auth::user()->hasRole('fundamental')){ echo 'datepickerFundamental'; } else if(\Auth::user()->hasRole('pro')){ echo 'datepickerPro'; }else if(\Auth::user()->hasRole('freebies')){ echo 'datepickerFreebies'; } else{ echo 'datepickerFreebies';}?>" id="<?php if(\Auth::user()->hasRole('superior')){ echo 'datepickerSuperior'; }else if(\Auth::user()->hasRole('fundamental')){ echo 'datepickerFundamental'; } else if(\Auth::user()->hasRole('pro')){ echo 'datepickerPro'; }else if(\Auth::user()->hasRole('freebies')){ echo 'datepickerFreebies'; } else{ echo 'datepickerFreebies';}?>">
                                    <input type="text" class="@if(\Auth::user()->hasRole('fundamental'))datepickerFundamental @elseif(\Auth::user()->hasRole('superior')) datepickerSuperior @elseif(\Auth::user()->hasRole('pro')) datepickerPro @else datepickerFreebies @endif form-control"style="width: 100%"  id="fromDate" name="fromDate" onkeydown="return false" value="@if(isset($alertReports)) {{$from}} @endif"  autocomplete="off"  required>
                                    <span class="input-group-addon" style="z-index: auto;">
                                <span class="calendern"  style=""><i class="fa fa-calendar"></i></span>
                            </span>
                          </div>
                                  </div>
                                </div>
                                <div class="col-lg-2 col-md-2"> 
                                  <div class="form-group">                     
                                    <label> To Date</label>
                                    <div class="input-group date <?php if(\Auth::user()->hasRole('superior')){ echo 'datepickerSuperior'; }else if(\Auth::user()->hasRole('fundamental')){ echo 'datepickerFundamental'; } else if(\Auth::user()->hasRole('pro')){ echo 'datepickerPro'; }else if(\Auth::user()->hasRole('freebies')){ echo 'datepickerFreebies'; } else{ echo 'datepickerFreebies';}?>" id="<?php if(\Auth::user()->hasRole('superior')){ echo 'datepickerSuperior'; }else if(\Auth::user()->hasRole('fundamental')){ echo 'datepickerFundamental'; } else if(\Auth::user()->hasRole('pro')){ echo 'datepickerPro'; }else if(\Auth::user()->hasRole('freebies')){ echo 'datepickerFreebies'; } else{ echo 'datepickerFreebies';}?>"> 
                                    <input type="text" class="@if(\Auth::user()->hasRole('fundamental'))datepickerFundamental @elseif(\Auth::user()->hasRole('superior')) datepickerSuperior @elseif(\Auth::user()->hasRole('pro')) datepickerPro @else datepickerFreebies @endif form-control" style="width: 100%" id="toDate" name="toDate" onkeydown="return false"  value="@if(isset($alertReports)) {{$to}} @endif"  autocomplete="off" required>
                                    <span class="input-group-addon" style="z-index: auto;">
                                <span class="calendern"  style=""><i class="fa fa-calendar"></i></span>
                            </span>
                          </div>
                                  </div>
                                </div>
                                <div class="col-lg-3 col-md-3 pt-5">  
                                  <div>          
                                    <button type="submit" class="btn btn-sm btn-info btn2 srch" > <i class="fa fa-search"></i> </button>

                                              <button type="button" class="btn btn-sm btn1 btn-primary dwnld" onclick="downloadAlertReport()" ><i class="fa fa-file download-icon" ></i>Download Excel</button>
                                   </div>
                                   <style type="text/css">
                                     

                                   </style>
                                </div> 
                              <div class="col-lg-3">  
                                  
                                </div>                    
                              </div>
                            </div>
                          </div>
                        </form> 
                      </div>
                                        
                        @if(isset($alertReports))                
                        <table class="table table-hover table-bordered  table-striped datatable" style="width:100%;text-align: center" >
                          <thead>
                            <tr style="text-align: center;">
                              <th><b>SL.No</b></th>
                              <th><b>Vehicle</b></th>
                              <th><b>Registration number</b></th>
                              <th><b>Alert Type</b></th>                             
                              <th><b>Date & Time</b></th>  
                              <th><b>Action</b></th>                                   
                            </tr>
                          </thead>
                          <tbody>
                            @if($alertReports->count() == 0)
                            <tr>
                              <td></td>
                              <td></td>
                              <td><b style="float: right;margin-right: -13px">No data</b></td>
                              <td><b style="float: left;margin-left: -15px">Available</b></td>
                              <td></td>
                              <td></td>
                            </tr>
                            @endif

                            @foreach($alertReports as $alertReport)                  
                            <tr> 
                              <td>{{ (($perPage * ($page - 1)) + $loop->iteration) }}</td>
                              <td>{{ $alertReport->gps->vehicle->name}}</td>
                              <td>{{ $alertReport->gps->vehicle->register_number }}</td>
                              <td>{{ $alertReport->alertType->description }}</td>                                      
                              <td>{{ $alertReport->device_time }}</td>  
                              <td> <a href="/alert/report/{{Crypt::encrypt($alertReport->id)}}/mapview"class='btn btn-xs btn-info'><i class='glyphicon glyphicon-map-marker'></i> Map view </a></td>        
                            </tr>
                            @endforeach
                          </tbody>
                        </table>
                        {{ $alertReports->appends(['sort' => 'votes','vehicle' =>$vehicle_id,'alert' => $alert_id,'fromDate' =>$from,'toDate' => $to])->links() }}
                        @endif
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>       
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection
