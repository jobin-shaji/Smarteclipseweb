<?php

Route::group(['middleware' => ['web','auth','role:client|school'] , 'namespace' => 'App\Modules\Reports\Controllers' ] , function() {


	// geofence report
	Route::get('/geofence-report','GeofenceReportController@geofenceReport')->name('geofence-report');
	Route::post('/geofence-report-list','GeofenceReportController@geofenceReportList')->name('geofence-report-list');
	Route::post('/geofence-report/export','GeofenceReportController@export')->name('geofence.report.export');

	// fuel report
	Route::get('/fuel-report','FuelReportController@fuelReport')->name('fuel-report');
	Route::get('/fuel-reports','FuelReportController@fuelReports')->name('fuel-reports');
	Route::get('/driver-fuel-report','FuelReportController@driverFuelReport')->name('driver.fuel.report');
	Route::post('/driver-fuel-graph','FuelReportController@getDriverFuelGraphDetails')->name('driver.fuel.graph');
	Route::get('/vehicle-fuel-report','FuelReportController@vehicleFuelReport')->name('vehicle.fuel.report');
	Route::post('/vehicle-fuel-graph','FuelReportController@getVehicleFuelGraphDetails')->name('vehicle.fuel.graph');

	Route::post('/fuel-report-list','FuelReportController@fuelReportList')->name('fuel-report-list');
	Route::post('/fuel-graph','FuelReportController@getFuelGraphDetails')->name('fuel.graph');
	// Route::post('/month-fuel-graph','FuelReportController@getMonthFuelGraphDetails')->name('month.fuel.graph');
	Route::post('/drivers-vehicle/','FuelReportController@getFromListRoot')->name('drivers.vehicle');

	// alert report
	Route::get('/alert-report','AlertReportController@alertReport')->name('alert-report');
	Route::get('/alert-report-list','AlertReportController@alertReportList')->name('alert-report-list');
	// Route::post('/alert-report-list-demo','AlertReportController@alertReportListDemo')->name('alert-report-list-demo');

	Route::get('/alert/report/{id}/mapview','AlertReportController@location')->name('alert.report.mapview');
	Route::get('/alert/report/{id}/map_view','AlertReportController@alertMapView')->name('alert.report.map_view');
	Route::post('/alert/report/show','AlertReportController@alertmap')->name('alert.report.show');
	Route::post('/alert-report/export','AlertReportController@export')->name('alert.report.export');
	// tracking report
	Route::get('/tracking-report','TrackingReportController@trackingReport')->name('tracking-report');
	Route::post('/track-report-list','TrackingReportController@trackReportList')->name('track-report-list');
	
	// route deviation report
	Route::get('/route-deviation-report','RouteDeviationReportController@routeDeviationReport')->name('route-deviation-report');
 	Route::post('/route-deviation-report-list','RouteDeviationReportController@routeDeviationReportList')->name('route-deviation-report-list');
 	Route::post('/route-report/export','RouteDeviationReportController@export')->name('route.report.export');


 	// harsh braking report
	Route::get('/harsh-braking-report','HarshBrakingReportController@harshBrakingReport')->name('harsh-braking-report');
	Route::post('/harsh-braking-report-list','HarshBrakingReportController@harshBrakingReportList')->name('harsh-braking-report-list');
	Route::post('/harsh-braking-report/export','HarshBrakingReportController@export')->name('harsh.braking.report.export');

	//sudden acceleration report
	Route::get('/sudden-acceleration-report','SuddenAccelerationReportController@suddenAccelerationReport')->name('sudden-acceleration-report');
	Route::post('/sudden-acceleration-report-list','SuddenAccelerationReportController@suddenAccelerationReportList')->name('sudden-acceleration-report-list');
	Route::post('/sudden-acceleration-report/export','SuddenAccelerationReportController@export')->name('sudden.acceleration.report.export');

	//total km report
	Route::get('/total-km-report','TotalKMReportController@totalKMReport')->name('total-km-report');
	Route::post('/totalkm-report-list','TotalKMReportController@totalKMReportList')->name('totalkm-report-list');
	Route::post('/total-km-report/export','TotalKMReportController@export')->name('total.km.report.export');


	// vehicle report
	Route::get('/vehicle-report','TotalKMReportController@vehicleReport')->name('vehicle-report');
	Route::post('/vehicle-report-list','TotalKMReportController@vehicleReportList')->name('vehicle-report-list');

	//Daily KM report
	Route::get('/daily-km-report','DailyKMReportController@dailyKMReport')->name('daily-km-report');
	Route::post('/dailykm-report-list','DailyKMReportController@dailyKMReportList')->name('dailykm-report-list');
	Route::post('/daily-km-report/export','DailyKMReportController@export')->name('daily.km.report.export');

	//over-speed-report
	Route::get('/over-speed-report','OverSpeedReportController@overSpeedReport')->name('over-speed-report');
	Route::post('/over-speed-report-list','OverSpeedReportController@overSpeedReportList')->name('over-speed-report-list');
	Route::post('/over-speed-report/export','OverSpeedReportController@export')->name('over.speed.report.export');

	//zigzag-driving-report
	Route::get('/zigzag-driving-report','ZigZagDrivingReportController@zigZagDrivingReport')->name('zigzag-driving-report');
	Route::post('/zigzag-driving-report-list','ZigZagDrivingReportController@zigZagDrivingReportList')->name('zigzag-driving-report-list');
	Route::post('/zigzag-driving-report/export','ZigZagDrivingReportController@export')->name('zigzag.driving.report.export');


	//accident-imapct-alert-report
	Route::get('/accident-imapct-alert-report','AccidentImpactAlertReportController@accidentImpactAlertReport')->name('accident-imapct-alert-report');
	Route::post('/accident-impact-alert-report-list','AccidentImpactAlertReportController@accidentImpactAlertReportList')->name('accident-impact-alert-report-list');
	Route::post('/accident-imapct-alert-report/export','AccidentImpactAlertReportController@export')->name('accident.imapct.alert.report.export');



	//Halt report(Idle report)
	Route::get('/idle-report','IdleReportController@idleReport')->name('idle-report');
	Route::post('/idle-report-list','IdleReportController@idleReportList')->name('idle-report-list');

	//parking report
	Route::get('/parking-report','ParkingReportController@parkingReport')->name('parking-report');
	Route::post('/parking-report-list','ParkingReportController@parkingReportList')->name('parking-report-list');

	Route::get('/offline-report','OfflineReportController@accidentImpactAlertReport')->name('offline-report');

	//main battery disconnect report
	Route::get('/mainbattery-disconnect-report','MainBatteryDisconnectReportController@mainBatteryDisconnectReport')->name('mainbattery-disconnect-report');
	Route::post('/mainbattery-disconnect-report-list','MainBatteryDisconnectReportController@mainBatteryDisconnectReportList')->name('mainbattery-disconnect-report-list');
	Route::post('/main-battery-disconnect-report/export','MainBatteryDisconnectReportController@export')->name('main.battery.disconnect.report.export');


	// test mode change
  Route::get('/mode-changes','TrackingReportController@modeTime')->name('mode-changes');

	// test mode change

  	//duration report
	Route::get('/duration-report','DurationReportController@durationReport')->name('total-km-report');
	Route::post('/duration-report-list','DurationReportController@durationReportList')->name('duration-report-list');

	Route::get('/trip-report','TripReportController@TripReportView')->name('trip-report.view');
	Route::post('/trip-report','TripReportController@TripReport')->name('trip.report.p');
	
Route::get('/trip-report-download','TripReportController@TripReportDownload')->name('trip-report.download');
Route::post('/trip-report-download','TripReportController@TripReportDownloadList')->name('trip.report.download.list');



});

Route::group(['middleware' => ['web','auth','role:sub_dealer|trader'] , 'namespace' => 'App\Modules\Reports\Controllers' ] , function() {

	Route::get('/log-report','DeviceLogReportController@logReport')->name('log-report');
	Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');
	Route::get('/device-installation-report','DeviceInstallationReportController@installationReport')->name('device.installation.report');
	Route::post('/device-installation-report-list','DeviceInstallationReportController@installationReportList')->name('device.installation.report.list');
	// Route::post('/track-report/export','TrackingReportController@export')->name('track.report.export');
});

Route::group(['middleware' => ['web','auth','role:school'] , 'namespace' => 'App\Modules\Reports\Controllers' ] , function() {

	Route::get('/pickup-dropoff-report-based-on-student','PickupDropoffReportController@pickupReportBasedOnStudent')->name('pickup.dropoff.report.based.on.student');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');

	//missed-student-report
	Route::get('/missed-student-report','missedStudentReportController@missedStudentReport')->name('missed-student-report');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');
	//pickup-drop-off-report-based-on-bus
	Route::get('/pickup-dropoff-report-based-on-bus','PickupDropoffReportController@pickupReportBasedOnBus')->name('pickup-dropoff-report-based-on-bus');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');

	// special class bus
	Route::get('/special-class-bus-schedule-report','SpecialClassBusScheduleController@specialClassBusSchedule')->name('special-class-bus-schedule-report');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');

	//parent information report
	Route::get('/parent-information-report','ParentInformationReportController@parentInformationReport')->name('parent-information-report');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');

	////student-wise-usage-report
	Route::get('/student-wise-usage-report','StudentWiseUsageReportController@studentWiseUsageReport')->name('student-wise-usage-report');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');

	////nfc card report
	Route::get('/nfc-card-report','NfcCardReportController@nfcCardReport')->name('nfc-card-report');
	// Route::post('/log-report-list','DeviceLogReportController@logReportList')->name('log-report-list');


});

Route::group(['middleware' => ['web','auth','role:root'] , 'namespace' => 'App\Modules\Reports\Controllers' ] , function() {
	//trip report view in manufacturer
	Route::get('/trip-report-manufacturer','TripReportController@tripReportInManufacturer')->name('trip-report-manufacturer');
	Route::post('/trip-report-vehicle-dropdown-in-manufacturer','TripReportController@getVehiclesBasedOnClient')->name('trip-report-vehicle-dropdown-in-manufacturer');
	Route::post('/trip-report-manufacturer-search','TripReportController@getDetailsOfTripReportInManufacturer')->name('trip-report-manufacturer-search');
});

Route::group(['middleware' => ['web','auth','role:client'] , 'namespace' => 'App\Modules\Reports\Controllers' ] , function() {
	//trip report view in manufacturer
	Route::get('/trip-report-client','TripReportController@tripReportInClient')->name('trip-report-client');
	Route::post('/trip-report-client-search','TripReportController@getDetailsOfTripReportInClient')->name('trip-report-client-search');
});