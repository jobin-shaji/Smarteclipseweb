<?php
namespace App\Modules\Reports\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\Gps\Models\GpsData;
use App\Modules\Alert\Models\Alert;
use Illuminate\Support\Facades\Crypt;
use DataTables;
class OfflineReportController extends Controller
{
    public function harshBrakingReport()
    {
        return view('Reports::harsh-braking-report');  
    } 
    public function harshBrakingReportList(Request $request)
    {
        $client= $request->client;
         // $alert_id= $request->alertID;
        
        $from = $request->from_date;
        $to = $request->to_date;
      
       
            $query =Alert::select(
            'id',
            'alert_type_id', 
            'device_time',    
            'vehicle_id',
            'gps_id',
            'client_id',  
            'latitude',
            'longitude', 
            'status'
        )
        ->with('alertType:id,description')
        ->with('vehicle:id,name,register_number')
        ->where('client_id',$client)
        ->where('alert_type_id',1)
        ->orderBy('device_time', 'DESC');
        // ->where('status',1);
           
        if($from){
            $search_from_date=date("Y-m-d", strtotime($from));
                $search_to_date=date("Y-m-d", strtotime($to));
                $query = $query->whereDate('device_time', '>=', $search_from_date)->whereDate('device_time', '<=', $search_to_date);
        }
        $alert = $query->get();   

        return DataTables::of($alert)
        ->addIndexColumn()
        ->addColumn('location', function ($alert) {
            //      $latitude= $alert->latitude;
            //      $longitude=$alert->longitude;          
            //     if(!empty($latitude) && !empty($longitude)){
            //         //Send request and receive json data by address
            //         $geocodeFromLatLong = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($latitude).','.trim($longitude).'&sensor=false&key='.config("eclipse.keys.googleMap").'&libraries=drawing&callback=initMap'); 
            //         $output = json_decode($geocodeFromLatLong);         
            //         $status = $output->status;
            //         //Get address from json data
            //         $address = ($status=="OK")?$output->results[1]->formatted_address:'';
            //         //Return address of the given latitude and longitude
            //         if(!empty($address)){
            //              $location=$address;
            //         return $location;
                        
            //         }
                
            // }
            return "no address";
         })
         ->addColumn('action', function ($alert) {  
         $b_url = \URL::to('/');              
                    return "
                    <a href=".$b_url."/alert/report/".Crypt::encrypt($alert->id)."/mapview class='btn btn-xs btn-info'><i class='glyphicon glyphicon-map-marker'></i> Map view </a>";
                })
            ->rawColumns(['link', 'action'])
        ->make();
    } 
   
}