<?php
namespace App\Modules\Reports\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\Gps\Models\GpsData;
use DataTables;
class TerainRoadsConditionOperationTemperatureReportController extends Controller
{
    public function terainRoadConditionReport()
    {
        return view('Reports::terain-road-condition-report');  
    }  
   
}