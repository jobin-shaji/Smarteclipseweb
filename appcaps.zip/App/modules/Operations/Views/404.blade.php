@extends('layouts.eclipse') 
@section('content')
<div class="page-wrapper page-wrapper-root page-wrapper_new">
<div class="page-wrapper-root1">
	<div class="card-body">
	    <div class="pad margin no-print">
	      <div class="callout callout-danger" style="margin-bottom: 0!important;">
	      Operations does not exist !!!
	      </div>
	    </div>
	</div>
</div>
</div>
@endsection