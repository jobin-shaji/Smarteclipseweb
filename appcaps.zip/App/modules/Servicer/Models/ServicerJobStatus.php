<?php

namespace App\Modules\Servicer\Models;

use Illuminate\Database\Eloquent\Model;

class ServicerJobStatus extends Model
{
    protected $fillable = ['status'];
}
